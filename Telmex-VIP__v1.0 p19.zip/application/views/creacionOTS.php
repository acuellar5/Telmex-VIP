<h2>Creación de OT</h2>
<a href="#" class="btn btn-success btn-sm btn_crear_oth"><span class="glyphicon glyphicon-plus"></span> Crear OT</a>
<table id="oth_new_List" class="table table-hover table-bordered table-striped dataTable_camilo" style="width: 100%;">
   
        <tr>
            <th></th>
            <th></th>
            <th></th>
        </tr>

</table>