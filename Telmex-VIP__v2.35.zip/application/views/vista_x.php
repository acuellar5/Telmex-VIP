<div class="css_imagen8" style="width: 100%; height: 91%; padding: 0 !important; margin: 0; top: 53px; left: 0; right: 0; position: absolute;">
    <img  style="width: 100%; height: 100%;" src="<?= URL::to('assets/img/img8.png') ?>">
    </div>
    <div class="col-md-9 col-sm-9">
        <div style="height: 400px;"></div>
    <img class="m-b-25" src="<?= URL::to('assets/img/logoClaro.png') ?>" width="100"/>
    <div class="head-last"><!--texto aca--> </div>
</div>


